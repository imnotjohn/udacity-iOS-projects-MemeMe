//
//  MemeCollectionViewCell.swift
//  ProjectMemeMe
//
//  Created by J on 27/12/16.
//  Copyright © 2016 Udacity. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellImageView : UIImageView!
}
